package com.example.dashcontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Teste extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teste);
    }
}